﻿import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
import fs from 'fs'
import path from 'path'
import child_process from 'child_process'
import { env } from 'process'

/* ---------- HTTPS cert (your current ASP.NET dev cert logic) ---------- */
const baseFolder =
    env.APPDATA && env.APPDATA !== ''
        ? `${env.APPDATA}/ASP.NET/https`
        : `${env.HOME}/.aspnet/https`

const certificateName = 'videorecorder.client'
const certFilePath = path.join(baseFolder, `${certificateName}.pem`)
const keyFilePath = path.join(baseFolder, `${certificateName}.key`)

if (!fs.existsSync(baseFolder)) fs.mkdirSync(baseFolder, { recursive: true })

if (!fs.existsSync(certFilePath) || !fs.existsSync(keyFilePath)) {
    const res = child_process.spawnSync(
        'dotnet',
        ['dev-certs', 'https', '--export-path', certFilePath, '--format', 'Pem', '--no-password'],
        { stdio: 'inherit' }
    )
    if (res.status !== 0) throw new Error('Could not create certificate.')
}

const target = env.ASPNETCORE_HTTPS_PORT
    ? `https://localhost:${env.ASPNETCORE_HTTPS_PORT}`
    : env.ASPNETCORE_URLS
        ? env.ASPNETCORE_URLS.split(';')[0]
        : 'https://localhost:7068'

/* ---------- Base path (root by default; set VITE_BASE=/YourApp/ for IIS virtual dir) ---------- */
const appBase = (env.VITE_BASE || '/').replace(/\/?$/, '/')

// Files expected in /public:
//   public/pwa-192x192.png
//   public/pwa-512x512.png
//   (optional) public/pwa-maskable-512.png
export default defineConfig({
    base: appBase,
    plugins: [
        react(),

        VitePWA({
            /* We manually call registerSW() in your entry, so don't auto-inject */
            injectRegister: null,
            registerType: 'autoUpdate',

            /* Enable SW in dev so you can test install/offline on https://localhost */
            devOptions: { enabled: true },

            includeAssets: ['robots.txt', 'favicon.svg', 'apple-touch-icon.png'],

            manifest: {
                name: 'Video Recorder',
                short_name: 'Recorder',
                start_url: appBase,        // critical for install prompt
                scope: appBase,            // keep scope aligned with base
                display: 'standalone',
                background_color: '#111827',
                theme_color: '#111827',
                icons: [
                    { src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' },
                    { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png' },
                    { src: 'pwa-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
                ],
            },

            workbox: {
                /* Single-page app fallback (IIS also rewrites to /index.html) */
                navigateFallback: 'index.html',

                runtimeCaching: [
                    {
                        // HTML documents
                        urlPattern: ({ request }) => request.destination === 'document',
                        handler: 'NetworkFirst',
                        options: { cacheName: 'pages' },
                    },
                    {
                        // JS/CSS
                        urlPattern: ({ request }) =>
                            request.destination === 'script' || request.destination === 'style',
                        handler: 'StaleWhileRevalidate',
                        options: { cacheName: 'assets' },
                    },
                    {
                        // images/fonts
                        urlPattern: ({ request }) =>
                            ['image', 'font'].includes(request.destination),
                        handler: 'CacheFirst',
                        options: {
                            cacheName: 'static',
                            expiration: { maxEntries: 100, maxAgeSeconds: 60 * 60 * 24 * 30 },
                        },
                    },
                ],
            },
        }),
    ],

    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url)),
        },
    },

    server: {
        proxy: {
            '^/weatherforecast': {
                target,
                secure: false,
            },
        },
        port: parseInt(env.DEV_SERVER_PORT || '30151', 10),
        host: true,
        https: {
            key: fs.readFileSync(keyFilePath),
            cert: fs.readFileSync(certFilePath),
        },
    },
})
